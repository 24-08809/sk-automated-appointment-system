'use client'

import { useState } from 'react'
import {
  ArrowRight,
  Bell,
  CalendarDays,
  Check,
  ChevronDown,
  Clock3,
  FileText,
  LayoutDashboard,
  Menu,
  MoreHorizontal,
  Plus,
  Search,
  Settings2,
  ShieldCheck,
  Users,
  X,
} from 'lucide-react'

const navItems = [
  { label: 'Dashboard', icon: LayoutDashboard },
  { label: 'Appointments', icon: CalendarDays },
  { label: 'Residents', icon: Users },
  { label: 'Documents', icon: FileText },
]

const appointments = [
  { name: 'Maria Santos', initials: 'MS', service: 'Certificate of Residency', date: 'Today, 9:30 AM', status: 'Confirmed', color: 'bg-[#dff4ee] text-[#14856f]' },
  { name: 'Jomar Reyes', initials: 'JR', service: 'Youth ID Application', date: 'Today, 10:15 AM', status: 'Pending', color: 'bg-[#fff1d8] text-[#a56b08]' },
  { name: 'Aira Villanueva', initials: 'AV', service: 'Educational Assistance', date: 'Today, 1:00 PM', status: 'Confirmed', color: 'bg-[#dff4ee] text-[#14856f]' },
  { name: 'Carlo Dela Cruz', initials: 'CD', service: 'Barangay Clearance', date: 'Tomorrow, 8:45 AM', status: 'Pending', color: 'bg-[#fff1d8] text-[#a56b08]' },
]

const services = [
  { title: 'Certificate of Residency', description: 'Proof of residency for local requirements', time: '15–20 min', icon: ShieldCheck, tint: 'bg-[#e5f3f1]', iconColor: 'text-[#127e70]' },
  { title: 'Youth ID Application', description: 'Apply or update your SK youth identification', time: '20–30 min', icon: Users, tint: 'bg-[#eef0fa]', iconColor: 'text-[#5365b5]' },
  { title: 'Educational Assistance', description: 'Inquire about available financial support', time: '30–45 min', icon: FileText, tint: 'bg-[#fff1dc]', iconColor: 'text-[#bd7a13]' },
]

export default function Page() {
  const [activeNav, setActiveNav] = useState('Dashboard')
  const [showBooking, setShowBooking] = useState(false)
  const [booked, setBooked] = useState(false)

  function handleBook() {
    setBooked(true)
    setTimeout(() => {
      setShowBooking(false)
      setBooked(false)
    }, 1300)
  }

  return (
    <main className="min-h-screen bg-[#f6f8f8] text-[#182a36]">
      <div className="flex min-h-screen">
        <aside className="hidden w-[248px] flex-col border-r border-[#e3e9e8] bg-white px-5 py-6 lg:flex">
          <div className="mb-12 flex items-center gap-3 px-2">
            <div className="flex size-10 items-center justify-center rounded-[12px] bg-[#0b6b61] text-white shadow-sm"><ShieldCheck className="size-5" /></div>
            <div><p className="text-[15px] font-bold tracking-tight">SK Service</p><p className="text-[11px] text-[#80908e]">Appointment Portal</p></div>
          </div>
          <nav className="flex flex-col gap-2" aria-label="Primary navigation">
            <p className="mb-2 px-3 text-[10px] font-bold uppercase tracking-[0.18em] text-[#9baaa8]">Workspace</p>
            {navItems.map(({ label, icon: Icon }) => (
              <button key={label} onClick={() => setActiveNav(label)} className={`flex items-center gap-3 rounded-xl px-3 py-3 text-left text-[13px] font-semibold transition-colors ${activeNav === label ? 'bg-[#e5f3f1] text-[#0b6b61]' : 'text-[#70817f] hover:bg-[#f3f6f5]'}`}>
                <Icon className="size-[18px]" />{label}
                {label === 'Appointments' && <span className="ml-auto rounded-full bg-[#f1e2bf] px-2 py-0.5 text-[10px] text-[#9a6d19]">4</span>}
              </button>
            ))}
          </nav>
          <div className="mt-auto rounded-2xl bg-[#f0f7f5] p-4">
            <p className="mb-1 text-[11px] font-bold uppercase tracking-[0.14em] text-[#0b6b61]">Need help?</p>
            <p className="mb-3 text-xs leading-relaxed text-[#68807c]">Visit the SK office or send us a message.</p>
            <button className="flex items-center gap-1 text-xs font-bold text-[#0b6b61]">Contact SK <ArrowRight className="size-3" /></button>
          </div>
        </aside>

        <section className="min-w-0 flex-1">
          <header className="flex h-[76px] items-center justify-between border-b border-[#e3e9e8] bg-white px-5 sm:px-8 lg:px-10">
            <div className="flex items-center gap-3"><button className="rounded-lg p-2 text-[#6f8180] lg:hidden" aria-label="Open menu"><Menu className="size-5" /></button><div className="lg:hidden"><p className="text-sm font-bold">SK Service Portal</p></div><div className="hidden items-center gap-2 text-xs text-[#91a09e] sm:flex"><span>Home</span><span>/</span><span className="font-semibold text-[#263c43]">Dashboard</span></div></div>
            <div className="flex items-center gap-4"><button className="relative rounded-full p-2 text-[#70817f] hover:bg-[#f3f6f5]" aria-label="Notifications"><Bell className="size-[19px]" /><span className="absolute right-1.5 top-1.5 size-1.5 rounded-full bg-[#d69324]" /></button><div className="h-7 w-px bg-[#e4eae8]" /><button className="flex items-center gap-2"><div className="flex size-8 items-center justify-center rounded-full bg-[#e6d8c3] text-xs font-bold text-[#795d3f]">JD</div><div className="hidden text-left sm:block"><p className="text-xs font-bold">Juan Dela Cruz</p><p className="text-[10px] text-[#91a09e]">SK Staff</p></div><ChevronDown className="hidden size-3.5 text-[#8c9c99] sm:block" /></button></div>
          </header>

          <div className="mx-auto max-w-[1330px] px-5 py-8 sm:px-8 lg:px-10 lg:py-10">
            <div className="mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><p className="mb-2 text-xs font-bold uppercase tracking-[0.18em] text-[#c18a2a]">Monday, October 14, 2024</p><h1 className="text-3xl font-bold tracking-[-0.04em] text-[#1a3037] sm:text-[36px]">Good morning, Juan.</h1><p className="mt-2 text-sm text-[#7b8d8b]">Here&apos;s what&apos;s happening with your service desk today.</p></div><button onClick={() => setShowBooking(true)} className="flex w-fit items-center justify-center gap-2 rounded-xl bg-[#0b6b61] px-4 py-3 text-sm font-bold text-white shadow-[0_5px_12px_rgba(11,107,97,0.15)] transition-transform hover:-translate-y-0.5"><Plus className="size-4" /> New appointment</button></div>

            <div className="mb-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              {[['Today\'s appointments', '12', '+3 from yesterday', CalendarDays, 'bg-[#e5f3f1]', 'text-[#0b6b61]'], ['Pending approval', '04', 'Needs your attention', Clock3, 'bg-[#fff1dc]', 'text-[#b77513]'], ['Registered residents', '286', '+18 this month', Users, 'bg-[#eef0fa]', 'text-[#5268bc]'], ['Completed this month', '94%', '14 more than last month', Check, 'bg-[#e9f4ec]', 'text-[#3f9b68]']].map(([label, value, sub, Icon, tint, iconColor]) => <div key={label as string} className="rounded-2xl border border-[#e3e9e8] bg-white p-5 shadow-[0_2px_8px_rgba(38,60,67,0.02)]"><div className="mb-5 flex items-start justify-between"><p className="max-w-[130px] text-xs font-semibold leading-relaxed text-[#7a8d8b]">{label}</p><div className={`flex size-9 items-center justify-center rounded-xl ${tint}`}><Icon className={`size-[17px] ${iconColor}`} /></div></div><p className="text-[28px] font-bold tracking-[-0.04em] text-[#1b3138]">{value}</p><p className="mt-1 text-[11px] text-[#8d9b9a]">{sub}</p></div>)}
            </div>

            <div className="grid gap-6 xl:grid-cols-[1.45fr_1fr]">
              <div className="rounded-2xl border border-[#e3e9e8] bg-white p-5 sm:p-6"><div className="mb-5 flex items-center justify-between"><div><h2 className="text-base font-bold text-[#1d343a]">Today&apos;s appointments</h2><p className="mt-1 text-xs text-[#8a9a98]">October 14, 2024 · 8:00 AM – 5:00 PM</p></div><button className="flex items-center gap-1 text-xs font-bold text-[#0b6b61]">View calendar <ArrowRight className="size-3.5" /></button></div><div className="flex flex-col">{appointments.map((item, index) => <div key={item.name} className={`flex items-center gap-3 py-4 ${index !== appointments.length - 1 ? 'border-b border-[#edf1f0]' : ''}`}><div className="flex size-9 shrink-0 items-center justify-center rounded-full bg-[#e8dcca] text-[11px] font-bold text-[#795e43]">{item.initials}</div><div className="min-w-0 flex-1"><p className="truncate text-[13px] font-bold text-[#273c42]">{item.name}</p><p className="mt-0.5 truncate text-[11px] text-[#879795]">{item.service}</p></div><div className="hidden text-right sm:block"><p className="text-[11px] font-semibold text-[#506360]">{item.date}</p><span className={`mt-1 inline-flex rounded-full px-2 py-0.5 text-[10px] font-bold ${item.color}`}>{item.status}</span></div><button className="rounded-lg p-2 text-[#9aaba8] hover:bg-[#f3f6f5]" aria-label={`More options for ${item.name}`}><MoreHorizontal className="size-4" /></button></div>)}</div></div>

              <div className="rounded-2xl border border-[#e3e9e8] bg-white p-5 sm:p-6"><div className="mb-5 flex items-center justify-between"><div><h2 className="text-base font-bold text-[#1d343a]">Popular services</h2><p className="mt-1 text-xs text-[#8a9a98]">Quick access to SK services</p></div><button className="rounded-lg p-2 text-[#8b9b99] hover:bg-[#f3f6f5]" aria-label="Service settings"><Settings2 className="size-4" /></button></div><div className="flex flex-col gap-3">{services.map(({ title, description, time, icon: Icon, tint, iconColor }) => <button key={title} onClick={() => setShowBooking(true)} className="group flex items-center gap-3 rounded-xl border border-[#edf1f0] p-3 text-left transition-colors hover:border-[#b9dcd5] hover:bg-[#f8fbfa]"><div className={`flex size-10 shrink-0 items-center justify-center rounded-xl ${tint}`}><Icon className={`size-[18px] ${iconColor}`} /></div><div className="min-w-0 flex-1"><p className="truncate text-xs font-bold text-[#2a4046]">{title}</p><p className="mt-1 truncate text-[10px] text-[#8a9a98]">{description}</p><p className="mt-1 flex items-center gap-1 text-[10px] font-semibold text-[#78908b]"><Clock3 className="size-3" /> {time}</p></div><ArrowRight className="size-4 text-[#aec0bd] transition-transform group-hover:translate-x-0.5" /></button>)}</div><button onClick={() => setShowBooking(true)} className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-[#b9d4d0] py-3 text-xs font-bold text-[#0b6b61] hover:bg-[#f3faf8]"><Plus className="size-3.5" /> Add appointment</button></div>
            </div>

            <div className="mt-6 flex flex-col gap-4 rounded-2xl bg-[#103f45] p-6 text-white sm:flex-row sm:items-center sm:justify-between sm:px-8"><div><div className="mb-2 flex items-center gap-2"><span className="size-2 rounded-full bg-[#e7b55a]" /><p className="text-[10px] font-bold uppercase tracking-[0.16em] text-[#b8d1cc]">Community update</p></div><h2 className="text-lg font-bold">SK Youth General Assembly</h2><p className="mt-1 text-xs text-[#b6cfcb]">Join us on October 26 at the Barangay Hall. Registration is now open.</p></div><button className="flex w-fit items-center gap-2 rounded-lg bg-[#e6b65d] px-4 py-2.5 text-xs font-bold text-[#3e321d]">View details <ArrowRight className="size-3.5" /></button></div>
          </div>
        </section>
      </div>

      {showBooking && <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#173238]/35 p-4 backdrop-blur-sm"><div role="dialog" aria-modal="true" aria-labelledby="booking-title" className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl"><div className="mb-6 flex items-start justify-between"><div><p className="mb-1 text-[10px] font-bold uppercase tracking-[0.16em] text-[#c18a2a]">Service desk</p><h2 id="booking-title" className="text-xl font-bold text-[#1b3138]">Book an appointment</h2><p className="mt-1 text-xs text-[#879795]">Choose a service and preferred schedule.</p></div><button onClick={() => setShowBooking(false)} className="rounded-lg p-1 text-[#8b9b99] hover:bg-[#f2f5f4]" aria-label="Close dialog"><X className="size-5" /></button></div>{booked ? <div className="flex flex-col items-center py-8 text-center"><div className="mb-4 flex size-14 items-center justify-center rounded-full bg-[#dff4ee] text-[#14856f]"><Check className="size-7" /></div><h3 className="font-bold text-[#1b3138]">Appointment requested</h3><p className="mt-1 text-sm text-[#879795]">We&apos;ll confirm your schedule shortly.</p></div> : <div className="flex flex-col gap-4"><label className="flex flex-col gap-2 text-xs font-bold text-[#425754]">Service<select className="rounded-xl border border-[#dce7e4] bg-white px-3 py-3 text-sm font-normal text-[#304541] outline-none focus:border-[#0b6b61]"><option>Certificate of Residency</option><option>Youth ID Application</option><option>Educational Assistance</option></select></label><label className="flex flex-col gap-2 text-xs font-bold text-[#425754]">Preferred date<input type="date" defaultValue="2024-10-15" className="rounded-xl border border-[#dce7e4] px-3 py-3 text-sm font-normal text-[#304541] outline-none focus:border-[#0b6b61]" /></label><label className="flex flex-col gap-2 text-xs font-bold text-[#425754]">Preferred time<select className="rounded-xl border border-[#dce7e4] bg-white px-3 py-3 text-sm font-normal text-[#304541] outline-none focus:border-[#0b6b61]"><option>9:00 AM</option><option>10:30 AM</option><option>1:00 PM</option><option>2:30 PM</option></select></label><button onClick={handleBook} className="mt-2 rounded-xl bg-[#0b6b61] py-3.5 text-sm font-bold text-white hover:bg-[#095c53]">Request appointment</button></div>}</div></div>}
    </main>
  )
}
